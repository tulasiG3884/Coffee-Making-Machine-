MENU={
    'latte':{'ingredients':{'water':20,'milk':500,'sugar':10,'coffee':15},'price':30},
    'expresso':{'ingredients':{'water':30,'milk':600,'sugar':20,'coffee':25},'price':35},
    'cappachino':{'ingredients':{'water':40,'milk':700,'sugar':30,'coffee':35},'price':50}
}
RESOURCES={
    'water':200,
    'milk':1500,
    'sugar':100,
    'coffee':150,
}
PROFIT=0
def isIngredientsPresent(user_choice_ingredients):
    for item in user_choice_ingredients:
        if  not user_choice_ingredients[item]<=RESOURCES[item]:
            print(f'{item} is not sufficient')
            return False
    return True
def processPayment():
    amount=int(input('How many one rupee coins?'))
    amount+=int(input('How many two rupee coins?'))*2
    amount+=int(input('How many five rupee coins?'))*5
    amount+=int(input('How many ten rupee coins?'))*10
    return amount
def paymentSuccessful(totalAmount ,drinkcost):
    global PROFIT
    if totalAmount<drinkcost:
        print('Insufficient amount')
        print(f'take the amount of rupees{totalAmount}')
        return False
    else:
        print(f'take a change of {totalAmount-drinkcost}')
        PROFIT+=drinkcost 
        return True
    
def issueDrink(user_choice_ingredients):
    for item in user_choice_ingredients:
        RESOURCES[item]=RESOURCES[item]-user_choice_ingredients[item] 

isOnn=True
while isOnn:
    user_choice=input('enter your choice(latte,expresso,cappachino,off,report)')
    if user_choice=='off':
        isOnn=False
    elif user_choice=='report':
        print(RESOURCES,f'profit={PROFIT}')
    elif user_choice=='latte'or user_choice=='expresso'or user_choice=='cappachino':
        user_choice_ingredients=MENU[user_choice]['ingredients']
        if isIngredientsPresent(user_choice_ingredients):
            totalAmount=processPayment()
            drinkcost=MENU[user_choice]['price']
            if paymentSuccessful(totalAmount ,drinkcost):
                issueDrink(user_choice_ingredients)
                print(f'take the {user_choice}from the despenser')
    else:
        print('Please give avalid choice')